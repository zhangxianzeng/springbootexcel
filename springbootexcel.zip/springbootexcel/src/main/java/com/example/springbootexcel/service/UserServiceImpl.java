package com.example.springbootexcel.service;

import com.example.springbootexcel.dao.UserMapper;
import com.example.springbootexcel.pojo.User;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class UserServiceImpl implements UserService {


    @Autowired
    UserMapper userMapper;
    @Override
    public List<User> queryUserInfo() {
        return userMapper.queryUserInfo();
    }

    @Override
    public void addUserInfo(List<User> list) {

        userMapper.addUserInfo(list);
    }
}
