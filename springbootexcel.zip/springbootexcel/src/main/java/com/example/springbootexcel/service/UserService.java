package com.example.springbootexcel.service;

import com.example.springbootexcel.pojo.User;

import java.util.List;

public interface UserService {



    //查询所有
    List<User> queryUserInfo();
    //插入所有
    void addUserInfo(List<User> list);
}
