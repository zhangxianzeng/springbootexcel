package com.example.springbootexcel.controller;



import com.example.springbootexcel.pojo.User;
import com.example.springbootexcel.service.UserServiceImpl;
import com.example.springbootexcel.util.ExcelUtil;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import javax.servlet.http.HttpServletResponse;
import java.util.List;

@RestController
public class TestController {

    @Autowired
    UserServiceImpl userService;

//下载数据库中的数据到excel
    @RequestMapping("exportExcel")
    public void export(HttpServletResponse response){


        List<User> userList = userService.queryUserInfo();
        //导出操作
        ExcelUtil.exportExcel(userList,"用户信息","sheet1",User.class,"testDATA.xls",response);
    }
//向数据库中插入xml内容
    @RequestMapping("importExcel")
    public String importExcel(String filePath){
      //  String filePath = "/Users/zhangxianzeng/Downloads/1.xls";
        //解析excel，
        List<User> userList = ExcelUtil.importExcel(filePath,1,1,User.class);
        //也可以使用MultipartFile,使用 FileUtil.importExcel(MultipartFile file, Integer titleRows, Integer headerRows, Class<T> pojoClass)导入
       // System.out.println("导入数据一共【"+userList.size()+"】行");

        userService.addUserInfo(userList);
        List<User> userList2 = userService.queryUserInfo();
        return userList2.toString();

    }



}