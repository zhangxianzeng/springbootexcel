package com.example.springbootexcel.dao;

import com.example.springbootexcel.pojo.User;
import org.apache.ibatis.annotations.Mapper;
import org.springframework.stereotype.Component;

import java.util.List;
@Mapper
@Component
public interface UserMapper {
    List<User> queryUserInfo();


    //插入所有
    void addUserInfo(List<User> list);

}
