package com.example.springbootexcel;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SpringbootexcelApplicationTests {

    @Test
    void contextLoads() {
    }

}
